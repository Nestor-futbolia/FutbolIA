# Fútbol IA 2.0.0

Prototipo Android del motor multimercado solicitado.

Incluye:
- Interfaz local para analizar un partido.
- Mercados demostrativos: 1X2, goles, ambos anotan, goles por tiempo, córners y tarjetas.
- Arquitectura preparada para integrar datos reales.

Importante:
Los porcentajes de esta versión son demostrativos. No representan predicciones entrenadas con datos reales.

Para la siguiente etapa se debe conectar una fuente de datos deportivos con autorización y entrenar/validar el modelo sin usar información futura (evitando data leakage).
